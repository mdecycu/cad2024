以管理者身分執行 1_ipv6_network_setup.bat 批次檔案將會逐一執行 1_2022_cadlab_network_setup.reg 與 1_disable_ipv4.ps1, 其中會關閉系統的代理主機自動搜尋, 改用 ::4 作為 proxy server.

且會關閉 IPv4 網路協定, 開啟 IPv6 網路協定, 並將 DNS 設為中華電信, IPv6 網路位址從校方的 DHCP6 擷取動態 IP.