# 關閉 IPv4 網路
Disable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip

# 啟用 IPv6 網路
Enable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip6

# 設置 IPv6 網路中的 DNS 伺服器為 2001:b000:168::1 (中華電信)
$dnsServers = "2001:b000:168::1"
Set-DnsClientServerAddress -InterfaceAlias "*" -ServerAddresses $dnsServers

# 設定 IPv6 使用 DHCP 取得 IP 地址
# 這會讓網卡自動使用 DHCPv6 來配置 IPv6 地址
Set-NetIPInterface -InterfaceAlias "*" -AddressFamily IPv6 -Dhcp Enabled

# 列出所使用的 IPv6 網路通訊協定內容
Write-Host "DNS Server: $dnsServers"
Write-Host "IPv6 Address: DHCPv6"
