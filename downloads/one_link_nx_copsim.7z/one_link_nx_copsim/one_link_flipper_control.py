# pip install pyzmq cbor keyboard
# for CoppeliaSim 4.7.0 rev4waswwwzswswswswsw
from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import keyboard
import time

# 利用 zmqRemoteAPI 以 23000 對場景伺服器進行連線
client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')

# Get the handles of the ball objects
#ball_handle = sim.getObject('/Sphere')

sim.startSimulation()
print('Simulation started')

# Existing imports and setup code...

# Define the thread function
def main():
    sim.setThreadAutomaticSwitch(True)
    
    joint = sim.getObject('./joint')
    hammer = sim.getObject('./flipper')

    velocity = 0
    hammer_back = 0
    torque = 0
    sliding = 0
    orientation = sim.getJointPosition(joint, sim.handle_world)
    position = sim.getObjectPosition(hammer, sim.handle_world)
    
    while True:
        if keyboard.is_pressed('w'):
            print("w is pressed")
            velocity = 100
            torque = 200
            hammer_back = 0
            
        if keyboard.is_pressed('s'):
            print("s is pressed")
            hammer_back = 1
            torque = -200
            velocity = -100
            
        if hammer_back == 1:
            sim.setJointPosition(joint, -1, orientation)
        sim.setJointTargetPosition(joint, velocity)

        if keyboard.is_pressed('q'):
            # Stop simulation
            sim.stopSimulation()
            break
    
# Create a child thread
main()