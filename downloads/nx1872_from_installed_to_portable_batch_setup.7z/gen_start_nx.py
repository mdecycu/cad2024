import re

def process_line(line):
    # 處理一般格式的行
    match = re.match(r'^\s*(\w+)\s+(.+)$', line)
    if match:
        return match.groups()
    
    # 處理帶有 [數字] 的行
    match = re.match(r'^\s*\[\d+\]\s+(\w+)\s+(.+)$', line)
    if match:
        return match.groups()
    
    return None

# 讀取文件內容
with open('nx1872_menu_help_log_file_env_vars_raw.txt', 'r') as file:
    lines = file.readlines()

# 創建 start_nx.bat 文件
with open('start_nx_installed.bat', 'w') as bat_file:
    bat_file.write('@echo off\n')
    
    for line in lines[0:460]:  # 只處理到第 460 行
        result = process_line(line.strip())
        if result:
            var, value = result
            # 移除可能的引號
            value = value.strip('"')
            bat_file.write(f'set {var}={value}\n')
    
    # 啟動 NX
    bat_file.write('start ugraf.exe -nx\n')

print("start_nx_installed.bat 文件已生成。")