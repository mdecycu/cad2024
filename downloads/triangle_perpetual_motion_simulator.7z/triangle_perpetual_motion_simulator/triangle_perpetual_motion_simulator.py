# 以下的 zmq 程式庫已經過修改, 可以在 IPv4 與 IPv6 環境下使用
# 針對 CoppeliaSim 的 zmq 延伸程式, Python 需要安裝 cbor 與 pyzmq 等兩個模組
# pip install cbor pyzmq
from zmqRemoteApi_IPv6 import RemoteAPIClient
import keyboard
import math
# slope angle is 11.52788

deg = math.pi/180.
ang = 11.52788

# 利用以下程式碼連接 CoppeliaSim remote API server
# 第一個輸入變數若為 localhost 則只能控制與程式同在的場景
# 但若第一輸入變數為可連外的 IPv4 或 IPv6 address, 則可用來控制遠端電腦上的模擬場景
# 23000 為 CoppeliaSim 使用 ZMQ remote API 連線控制時內定的網路埠號
# client 與 server 的防火牆或代理主機必須讓此埠號的封包 (socket) 通過
client = RemoteAPIClient('localhost', 23000)

# 利用 getObject 取得場景中的 "sim" 物件參考對應值
sim = client.getObject('sim')

# 利用 sim 物件的 startSimulation() 方法啟動場景模擬
sim.startSimulation()

# 利用 getObject 取得 'marble' and 'sensor'  物件的參考對應值
marble = sim.getObject('./marble')
sensor = sim.getObject('./sensor')

# 透過變數屬性設定方法將 marble 設為 non-static, 意即具有 dynamic 特性
sim.setObjectInt32Param(marble, sim.shapeintparam_static, 0)

# Define the positions of the left and right slopes
left_slope_position = [-1.35, 0.1, 0.35]
right_slope_position = [1.35, 0.1, 0.35]
force = 2.68

# Set the initial position of the marble to the left highest point
#sim.setObjectPosition(marble, -1, [-0.825, -0.2, 1.625])

# Flag to indicate the direction of force
positive_force = True

# 主模擬程序
while True:
    if keyboard.is_pressed('q'):
        # 模擬執行期間, 將滑鼠停在場景, 鍵盤按下 q 可以終止模擬
        break


    r, dist, pt, obj, normal = sim.handleProximitySensor(sensor)
    res, dist2, point, obj2, n = sim.readProximitySensor(sensor)
    print(res)
    # Get the current position of the marble
    current_position1 = sim.getObjectPosition(marble, -1)
    current_position2 = sim.getObjectPosition(marble, -1)
    # 當鋼球碰觸感測器時
    if res > 0:

        # Check if the marble is on the left slope
        if current_position1[0] < current_position2[0]:
            # Apply a positive x-direction force to roll right
            sim.addForceAndTorque(marble, [force*math.cos(ang*deg), force*math.sin(ang*deg), 0], [0, 0, 0])
            positive_force = True
        else:
            # Apply a negative x-direction force to roll left
            sim.addForceAndTorque(marble, [-force*math.cos(ang*deg), -force*math.sin(ang*deg), 0], [0, 0, 0])
            positive_force = False

        # Reset the proximity sensor
        sim.resetProximitySensor(sensor)

# Stop the simulation
sim.stopSimulation()
