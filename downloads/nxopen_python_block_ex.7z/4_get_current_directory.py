import os

# Get the current directory of the script
current_directory = os.path.dirname(os.path.abspath(__file__))

print("Current directory:", current_directory)