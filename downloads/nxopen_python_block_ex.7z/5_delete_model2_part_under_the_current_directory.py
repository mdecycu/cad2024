import os

# Get the current directory of the script
current_directory = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(current_directory, 'model2.prt')

# Check if the file exists and delete it
if os.path.isfile(file_path):
    os.remove(file_path)
    print(f"{file_path} has been deleted.")
else:
    print(f"{file_path} does not exist.")
