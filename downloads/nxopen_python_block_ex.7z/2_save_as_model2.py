﻿# NX 2312
# Journal created by Admin on Fri Oct 18 16:04:02 2024 台北標準時間

#
import math
import NXOpen
def main() : 

    theSession  = NXOpen.Session.GetSession() #type: NXOpen.Session
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    # ----------------------------------------------
    #   Menu: File->Save As...
    # ----------------------------------------------
    partSaveStatus1 = workPart.SaveAs("C:\\tmp\\model2.prt")
    
    partSaveStatus1.Dispose()
    # ----------------------------------------------
    #   Menu: File->Close->All Parts
    # ----------------------------------------------
    # User Function call - UF_PART_ask_num_parts
    
    theSession.Parts.CloseAll(NXOpen.BasePart.CloseModified.CloseModified, None)
    
    workPart = NXOpen.Part.Null
    displayPart = NXOpen.Part.Null
    theSession.ApplicationSwitchImmediate("UG_APP_NOPART")
    
    # ----------------------------------------------
    #   Menu: Tools->Automation->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()