import NXOpen

def main():
    theSession = NXOpen.Session.GetSession()

    # 創建新的零件
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "開始")
    fileNew1 = theSession.Parts.FileNew()

    # 設定模板與單位
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    fileNew1.UseBlankTemplate = False
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    fileNew1.NewFileName = "C:\\tmp\\model1.prt"
    
    nXObject1 = fileNew1.Commit()
    workPart = theSession.Parts.Work
    theSession.DeleteUndoMark(markId1, None)

    # 創建草圖
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "進入草圖")
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)

    # 定義矩形的尺寸
    width = 100.0  # 寬度 100 mm
    height = 120.0  # 高度 120 mm

    # 在草圖中建立矩形的四個角點
    points = [
        NXOpen.Point3d(0.0, 0.0, 0.0),  # 左下角
        NXOpen.Point3d(width, 0.0, 0.0),  # 右下角
        NXOpen.Point3d(width, height, 0.0),  # 右上角
        NXOpen.Point3d(0.0, height, 0.0)  # 左上角
    ]

    # 創建線段
    lines = []
    for i in range(4):
        line = workPart.Curves.CreateLine(points[i], points[(i + 1) % 4])
        lines.append(line)

    # 將幾何圖形加入草圖
    for line in lines:
        sketchInPlaceBuilder1.AddGeometry(line, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)

    # 更新草圖
    sketchInPlaceBuilder1.Commit()
    sketchInPlaceBuilder1.Destroy()

if __name__ == '__main__':
    main()
