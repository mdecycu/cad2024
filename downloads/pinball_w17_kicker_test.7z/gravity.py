import math
g = -9.81
z = g*math.cos(0.1*math.pi/180)
y = g*math.sin(0.1*math.pi/180)
print(z, y)